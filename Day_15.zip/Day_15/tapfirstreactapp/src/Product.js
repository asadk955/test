import './Product.css';
import React from 'react';

//  Child Component
//UI Component Class
// Object Orientation
// Inheritance
// Overriding 
// modular
//Class approach
class  Product  extends React.Component {
 render (){
        return <div>
                    <p>Title :<b>{ this.props.title}</b> </p>
                    <img src={this.props.imageurl} width="100" height="100"/>
                    <p>Description:{this.props.description}</p>
                    <p>Quantity Available :{ this.props.quantity}</p>
                    <p>Unit Price:{this.props.unitprice}</p>
                    <p>LIkes:{this.props.likes}</p>
                </div> 
 }
}

// Function  component Style

/*function Product() {
    return (<h1>Best Flower Details</h1>);
}*/

export default Product;