import logo from './logo.svg';
import './App.css';
import Product  from './Product';

//  Root UI Component

function App() {
  return (
    <div className="App">
      <h1>Transflowers</h1>
      <hr/>
      
      <Product title="Gerbera"  
               description="Wedding Flower"
               imageurl="./images/gerbera.jpg"
               quantity="5600"
               unitprice="10"
               likes="56000">
      </Product>
      <Product title="Rose"  
               description="Valentine Flower"
               imageurl="./images/rose.jpg"
               quantity="5600"
               unitprice="15"
               likes="4500">
      </Product>
      <Product title="Lotus"  
               description="Worship Flower"
               imageurl="./images/lotus.jpg"
               quantity="45000"
               unitprice="35"
               likes="7600">
      </Product>

      <Product title="Marigold"  
               description="Valentine Flower"
               imageurl="./images/Transflower.jpg"
               quantity="8500"
               unitprice="5"
               likes="4500">
      </Product>

      <Product title="Jasmine"  
               description="Worship Flower"
               imageurl="./images/jasmine.jpg"
               quantity="15000"
               unitprice="25"
               likes="17600">
      </Product>


    </div>
  );
}

export default App;
